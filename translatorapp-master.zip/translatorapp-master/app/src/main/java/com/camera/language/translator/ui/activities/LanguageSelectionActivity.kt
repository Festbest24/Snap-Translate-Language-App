package com.camera.language.translator.ui.activities



import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.camera.language.translator.RecyclerViewItem
import com.camera.language.translator.databinding.ActivityLanguageSelectionBinding
import com.camera.language.translator.ui.adapters.LanguageSelectionAdapter
import com.camera.language.translator.utils.Constants
import com.camera.language.translator.utils.Util
import com.camera.language.translator.utils.Util.fromLanguage
import com.camera.language.translator.utils.Util.languageList
import com.camera.language.translator.utils.Util.languageType
import com.camera.language.translator.utils.Util.toLanguage
import com.example.translatordictionary.models.LanguageWithCountry
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class LanguageSelectionActivity : AppCompatActivity(), RecyclerViewItem {

    private lateinit var binding: ActivityLanguageSelectionBinding

    @Inject
    lateinit var constants: Constants
    lateinit var languageSelectionAdapter: LanguageSelectionAdapter
    var filteredList = ArrayList<LanguageWithCountry>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        binding.ivBack.setOnClickListener {
            onBackPressed()
        }
        languageSelectionAdapter = LanguageSelectionAdapter(this, constants)
        getSelectedLanguages()
        setLanguagesRecycler()

        val tabs = binding.include.tabLayout.getChildAt(0) as ViewGroup

        for (i in 0 until tabs.childCount) {
            val tab = tabs.getChildAt(i)
            val layoutParams = tab.layoutParams as LinearLayout.LayoutParams
            layoutParams.weight = 1f
            layoutParams.marginEnd = 25
            layoutParams.marginStart = 25
            tab.layoutParams = layoutParams
            binding.include.tabLayout.requestLayout()
        }


        binding.include.tabLayout.addOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> {
                        languageType = Util.languageSelectionTypeFrom
                        languageSelectionAdapter.notifyDataSetChanged()
                    }
                    1 -> {
                        languageType = Util.languageSelectionTypeTo
                        languageSelectionAdapter.notifyDataSetChanged()
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {

            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

        })
    }

    private fun getSelectedLanguages() {
        lifecycleScope.launch(Dispatchers.IO) {
            fromLanguage = constants.getFromLanguage()
            toLanguage = constants.getToLanguage()
        }
    }

    private fun setLanguagesRecycler() {
        CoroutineScope(Dispatchers.Main).launch {
            binding.rvLanguages.layoutManager = LinearLayoutManager(this@LanguageSelectionActivity)
            languageSelectionAdapter.submitList(languageList)
            binding.rvLanguages.adapter = languageSelectionAdapter
        }
    }

    override fun onItemClick(item: LanguageWithCountry) {

    }
}