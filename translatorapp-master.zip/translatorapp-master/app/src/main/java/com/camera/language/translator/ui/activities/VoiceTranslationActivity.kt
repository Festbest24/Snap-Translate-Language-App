package com.camera.language.translator.ui.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.camera.language.translator.databinding.ActivityVoiceTranslationBinding
import com.camera.language.translator.extensionfunction.launchActivity

class VoiceTranslationActivity : AppCompatActivity() {
    private lateinit var binding:ActivityVoiceTranslationBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityVoiceTranslationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.languageSelectionLayout.run {
            layoutFromLanguage.setOnClickListener {
                launchActivity<LanguageSelectionActivity>()
            }
            layoutToLanguage.setOnClickListener {
                launchActivity<LanguageSelectionActivity>()
            }
        }
    }
}