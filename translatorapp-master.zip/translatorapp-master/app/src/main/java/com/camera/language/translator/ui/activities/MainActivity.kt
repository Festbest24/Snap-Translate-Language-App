package com.camera.language.translator.ui.activities

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.lifecycleScope
import com.camera.language.translator.databinding.ActivityMainBinding
import com.camera.language.translator.extensionfunction.launchActivity
import com.camera.language.translator.utils.Util
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class MainActivity : AppCompatActivity() {
    private lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        lifecycleScope.launch(Dispatchers.Main) {
            Util.languageList =this.async {
                return@async Util.getLanguageWithCountryCode()
            }.await()
        }


        binding.run {
            cardVoiceTranslation.setOnClickListener {
                launchActivity<VoiceTranslationActivity>()
            }
            cardCameraTranslation.setOnClickListener {
                launchActivity<CameraActivity>()
            }
            cardDictionaryTranslate.setOnClickListener {
                launchActivity<TranslationActivity>()
            }
        }
    }
}