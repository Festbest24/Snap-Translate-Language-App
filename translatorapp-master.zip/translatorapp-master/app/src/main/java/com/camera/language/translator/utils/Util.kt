package com.camera.language.translator.utils

import android.net.Uri
import com.example.translatordictionary.models.DownloadingStates
import com.example.translatordictionary.models.LanguageWithCountry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow

object Util {

    suspend fun getLanguageWithCountryCode(): ArrayList<LanguageWithCountry> {
        val myList = CoroutineScope(Dispatchers.Default).async {
            val list = ArrayList<LanguageWithCountry>()
            val languages = arrayOf(
                "af",
                "sq",
                "ar",
                "be",
                "bg",
                "bn",
                "ca",
                "zh",
                "hr",
                "cs",
                "da",
                "nl",
                "en",
                "et",
                "fi",
                "fr",
                "gl",
                "ka",
                "de",
                "el",
                "gu",
                "ht",
                "he",
                "hi",
                "hu",
                "is",
                "id",
                "ga",
                "it",
                "ja",
                "kn",
                "ko",
                "lt",
                "lv",
                "mk",
                "mr",
                "ms",
                "mt",
                "no",
                "fa",
                "pl",
                "pt",
                "ro",
                "ru",
                "sk",
                "sl",
                "es",
                "sv",
                "sw",
                "tl",
                "ta",
                "te",
                "th",
                "tr",
                "uk",
                "ur",
                "vi",
                "cy"
            )
            val countries = arrayOf(
                "za",
                "al",
                "sa",
                "by",
                "bg",
                "bd",
                "es",
                "cn",
                "hr",
                "cz",
                "dk",
                "nl",
                "us",
                "ee",
                "fi",
                "fr",
                "es",
                "gs",
                "de",
                "gr",
                "in",
                "ht",
                "il",
                "in",
                "hu",
                "is",
                "id",
                "ie",
                "it",
                "jp",
                "in",
                "kp",
                "lt",
                "lv",
                "mk",
                "in",
                "in",
                "mt",
                "no",
                "ir",
                "pl",
                "pt",
                "ro",
                "ru",
                "sk",
                "sl",
                "es",
                "se",
                "tz",
                "ph",
                "in",
                "in",
                "th",
                "tr",
                "ua",
                "pk",
                "vn",
                "gb"
            )
            for (i in 0 until languages.size - 1) {
                list.add(LanguageWithCountry(languages[i], countries[i], false))
            }
            return@async list
        }
        return myList.await()
    }

    lateinit var downloadedList: List<String>

    var selectedFragment=1
    const val languageSelectionTypeFrom = "from"
    const val languageSelectionTypeTo = "to"
    const val languageSelectionType = "languageSelectionType"
    var languageType = "from"
    var fromLanguage = "en"
    var fromCountry = "us"
    var toCountry = "us"
    var toLanguage = "en"
    val downloadStatus = MutableStateFlow(DownloadingStates.Idle)
    var downloadingLanguage = ""
    var languageList = ArrayList<LanguageWithCountry>()
    var currentTextForTranslation = ""

    lateinit var imgFile: Uri




}