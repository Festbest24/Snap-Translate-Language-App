package com.camera.language.translator.ui.adapters

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.camera.language.translator.R
import com.camera.language.translator.RecyclerViewItem
import com.camera.language.translator.databinding.CustomLangugeViewBinding
import com.camera.language.translator.utils.Constants
import com.camera.language.translator.utils.Util
import com.camera.language.translator.utils.Util.fromLanguage
import com.camera.language.translator.utils.Util.languageType
import com.camera.language.translator.utils.Util.toLanguage
import com.example.translatordictionary.models.LanguageWithCountry
import com.murgupluoglu.flagkit.FlagKit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject


class LanguageSelectionAdapter @Inject constructor(private val onItemClickInterface: RecyclerViewItem, private val constants: Constants) :
    ListAdapter<LanguageWithCountry, LanguageSelectionAdapter.ViewHold>(CountryDiffUtils()) {

    inner class ViewHold(
        private val binding: CustomLangugeViewBinding,
        private val mContext: Context,
        private val onItemClickInterface: RecyclerViewItem
    ) : ViewHolder(binding.root) {

        fun bind(item: LanguageWithCountry) {

            var isDownloaded = false
//            Util.downloadedList.forEach {
//                if (it == item.languageCode) isDownloaded = true
//            }

            if (isDownloaded) {
                binding.ivDownloadStatus.run{
                    setImageResource(R.drawable.ic_downloaded)
                    isEnabled=false
                }
            }
            else {
                binding.ivDownloadStatus.run{
                    setImageResource(R.drawable.ic_download_now)
                    isEnabled=true
                }
            }


            binding.tvLanguageName.text = Locale(item.languageCode).displayName
            FlagKit.getResId(mContext, item.countryCode).also {
                binding.ivCountryFlag.setImageResource(it)
            }
            binding.languageCard.setOnClickListener {
                when (languageType) {
                    Util.languageSelectionTypeFrom -> {
                        fromLanguage = item.languageCode
                        CoroutineScope(Dispatchers.IO).launch {
                            constants.saveFromLanguage(item.languageCode)
                        }

                    }
                    Util.languageSelectionTypeTo -> {
                        toLanguage = item.languageCode
                        CoroutineScope(Dispatchers.IO).launch {
                            constants.saveToLanguage(item.languageCode)
                        }
                    }
                }
                (mContext as Activity).finish()
//                this@LanguageSelectionAdapter.notifyDataSetChanged()
            }
            binding.ivDownloadStatus.setOnClickListener {
                when (languageType) {
                    Util.languageSelectionTypeFrom -> {
                        fromLanguage = item.languageCode
                        CoroutineScope(Dispatchers.IO).launch {
                            constants.saveFromLanguage(item.languageCode)
                        }
                    }
                    Util.languageSelectionTypeTo -> {
                        toLanguage = item.languageCode
                        CoroutineScope(Dispatchers.IO).launch {
                            constants.saveToLanguage(item.languageCode)
                        }
                    }
                }
                onItemClickInterface.onItemClick(item)
                this@LanguageSelectionAdapter.notifyDataSetChanged()
            }

            if(Util.downloadingLanguage==item.languageCode){
                binding.ivDownloadStatus.visibility=View.GONE
                binding.progressBar.visibility=View.VISIBLE
            }else{
                binding.ivDownloadStatus.visibility=View.VISIBLE
                binding.progressBar.visibility=View.GONE
            }

            val selectedLanguage = when (languageType) {
                Util.languageSelectionTypeFrom -> {
                    fromLanguage
                }
                Util.languageSelectionTypeTo -> {
                    toLanguage
                }
                else -> {
                    ""
                }
            }

            if (selectedLanguage == item.languageCode)
                selectedCard(binding)
            else
                unselectedCard(binding)
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHold {
        val binding =
            CustomLangugeViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHold(binding, parent.context, onItemClickInterface)
    }

    override fun onBindViewHolder(holder: ViewHold, position: Int) {
        holder.bind(getItem(position))
    }


    class CountryDiffUtils : DiffUtil.ItemCallback<LanguageWithCountry>() {
        override fun areItemsTheSame(
            oldItem: LanguageWithCountry, newItem: LanguageWithCountry
        ): Boolean {
            return oldItem.languageCode == newItem.languageCode
        }

        override fun areContentsTheSame(
            oldItem: LanguageWithCountry, newItem: LanguageWithCountry
        ): Boolean {
            return oldItem == newItem
        }

    }

    private fun selectedCard(binding: CustomLangugeViewBinding) {
        binding.run {
            languageCard.setBackgroundResource(R.drawable.card_language_selected)
            tvLanguageName.setTextColor(Color.WHITE)
            ivDownloadStatus.setColorFilter(Color.WHITE)
            progressBar.indeterminateTintList=ColorStateList.valueOf(Color.WHITE)
        }
    }

    private fun unselectedCard(binding: CustomLangugeViewBinding) {
        binding.run {
            languageCard.setBackgroundResource(R.drawable.card_language_unselected)
            tvLanguageName.setTextColor(Color.BLACK)
            ivDownloadStatus.setColorFilter(Color.GRAY)
            progressBar.indeterminateTintList=ColorStateList.valueOf(Color.BLACK)
        }
    }

}