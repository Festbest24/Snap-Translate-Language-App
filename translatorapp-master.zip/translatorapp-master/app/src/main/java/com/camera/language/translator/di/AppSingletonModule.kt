package com.camera.language.translator.di

import android.content.Context
import com.camera.language.translator.utils.Constants
import com.google.mlkit.common.model.RemoteModelManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton


@InstallIn(SingletonComponent::class)
@Module
class AppSingletonModule() {


    @Singleton
    @Provides
    fun providesRemoteModelManager():RemoteModelManager=RemoteModelManager.getInstance()

    @Singleton
    @Provides
    fun provideConstants(@ApplicationContext mContext: Context): Constants {
        return Constants(mContext)
    }
//
//    @Provides
//    fun provideBaseBaseURL()=AppConstants.BASE_URL

    @Singleton
    @Provides
    fun provideRetrofitClient(
        BASE_URL: String
    ):Retrofit{
        return Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(
                OkHttpClient
                .Builder()
                .build())
            .build()
    }
//
//    @Singleton
//    @Provides
//    fun provideNetworkClient(retrofit: Retrofit):WordDetailsService = retrofit.create(WordDetailsService::class.java)



}