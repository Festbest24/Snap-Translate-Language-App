package com.example.translatordictionary.models

enum class DownloadingStates {
    Idle,
    Success,
    Downloading,
    Failed
}