package com.camera.language.translator

import androidx.fragment.app.Fragment
import com.example.translatordictionary.models.LanguageWithCountry


interface RecyclerViewItem{
    fun onItemClick(item:LanguageWithCountry)
}