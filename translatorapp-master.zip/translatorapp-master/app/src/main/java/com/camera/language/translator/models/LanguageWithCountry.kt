package com.example.translatordictionary.models

data class LanguageWithCountry(val languageCode:String, val countryCode:String, val downloaded:Boolean)
