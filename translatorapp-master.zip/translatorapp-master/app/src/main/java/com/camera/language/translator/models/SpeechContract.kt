package com.example.translatordictionary.models

import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.result.contract.ActivityResultContract
import com.camera.language.translator.utils.Util


class SpeechContract:ActivityResultContract<String,String>() {
    override fun createIntent(context: Context, input: String): Intent {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        //Specify language
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Util.fromLanguage)
        // Specify language model
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text")
        return intent
    }

    override fun parseResult(resultCode: Int, intent: Intent?):String {
        return intent?.let { myintent->
            val res=myintent.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) as ArrayList<String>
            res[0]
        }?:run{
            ""
        }
    }
}

class SpeechVoiceContract:ActivityResultContract<String,String>() {
    override fun createIntent(context: Context, input: String): Intent {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        //Specify language
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, input)
        // Specify language model
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text")
        return intent
    }

    override fun parseResult(resultCode: Int, intent: Intent?):String {
        return intent?.let { myintent->
            val res=myintent.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS) as ArrayList<String>
            res[0]
        }?:run{
            ""
        }
    }
}