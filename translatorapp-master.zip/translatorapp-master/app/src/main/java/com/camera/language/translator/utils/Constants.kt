package com.camera.language.translator.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Context.CLIPBOARD_SERVICE
import android.content.Context.INPUT_METHOD_SERVICE
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.QUEUE_FLUSH
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.content.ContextCompat.startActivity
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.camera.language.translator.ui.activities.dataStore
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.*
import javax.inject.Inject


class Constants @Inject constructor(
    @ApplicationContext val mContext: Context,
) {

    var tts: TextToSpeech? = null
    val mutableSpeakingResult = MutableStateFlow("done")

    fun copyText(text: String) {
        val clipboard: ClipboardManager =
            mContext.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("dictionary", text)
        clipboard.setPrimaryClip(clip)
    }

    fun makeToast(text: String) {
        Toast.makeText(mContext, text, Toast.LENGTH_SHORT).show()
    }

    fun speak(text: String, locale: Locale) {

        tts = TextToSpeech(mContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(locale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    Log.e("status", "The Language not supported!")
                    // Check by launching intent whether TTS is available or not
                    val installIntent = Intent()
                    installIntent.action = TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA
                    installIntent.flags = FLAG_ACTIVITY_NEW_TASK
                    startActivity(mContext, installIntent, null)
                } else {
                    Log.e("status", "Init Success")
                    tts?.speak(text, QUEUE_FLUSH, null, text)
                }

                tts?.let {
                    it.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            CoroutineScope(Dispatchers.IO).launch {
                                mutableSpeakingResult.emit("start")
                            }
                        }

                        override fun onDone(utteranceId: String?) {
                            CoroutineScope(Dispatchers.IO).launch {
                                mutableSpeakingResult.emit("done")
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            CoroutineScope(Dispatchers.IO).launch {
                                mutableSpeakingResult.emit("done")
                            }
                        }

                        override fun onStop(utteranceId: String?, interrupted: Boolean) {
                            super.onStop(utteranceId, interrupted)
                            CoroutineScope(Dispatchers.IO).launch {
                                mutableSpeakingResult.emit("done")
                            }
                        }
                    })
                }
            }
        }
    }

    suspend fun saveFromLanguage(value: String) {
        mContext.dataStore.edit {
            it[stringPreferencesKey("fromLanguage")] = value
        }
    }

    suspend fun getFromLanguage(): String {
        val preferences = mContext.dataStore.data.first()
        val value = preferences[stringPreferencesKey("fromLanguage")]
        value?.let {
            return value
        } ?: run {
            return "en"
        }
    }

    suspend fun saveToLanguage(value: String) {
        mContext.dataStore.edit {
            it[stringPreferencesKey("toLanguage")] = value
        }
    }

    suspend fun getToLanguage(): String {
        val preferences = mContext.dataStore.data.first()
        val value = preferences[stringPreferencesKey("toLanguage")]
        value?.let {
            return value
        } ?: run {
            return "en"
        }
    }

    suspend fun swapLanguages() {
        saveFromLanguage(Util.toLanguage)
        saveToLanguage(Util.fromLanguage)
    }

    fun getTextFromImage(uri: Uri): Flow<String> {

        val mutableFlow = MutableStateFlow("")

        val textRecognizerOptions = TextRecognizerOptions.DEFAULT_OPTIONS
        val chineseTextRecognizerOptions = ChineseTextRecognizerOptions.Builder().build()
        val devanagariTextRecognizerOptions = DevanagariTextRecognizerOptions.Builder().build()
        val japaneseTextRecognizerOptions = JapaneseTextRecognizerOptions.Builder().build()
        val koreanTextRecognizerOptions = KoreanTextRecognizerOptions.Builder().build()
        val image: InputImage
        try {
            image = InputImage.fromFilePath(mContext, uri)
        } catch (e: IOException) {
            e.printStackTrace()
            CoroutineScope(Dispatchers.IO).launch {
                mutableFlow.emit("Error")
            }
            return mutableFlow

        }
        CoroutineScope(Dispatchers.IO).launch {
            val recognizer = TextRecognition.getClient(textRecognizerOptions)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank())
                        CoroutineScope(Dispatchers.IO).launch {
                            mutableFlow.emit(visionText.text)
                        }
                }
                .addOnFailureListener { e ->
                    launch {
                        mutableFlow.emit("Error")
                    }

                }
        }

        CoroutineScope(Dispatchers.IO).launch {
            val recognizer = TextRecognition.getClient(chineseTextRecognizerOptions)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank())
                        CoroutineScope(Dispatchers.IO).launch {
                            mutableFlow.emit(visionText.text)
                        }
                }
                .addOnFailureListener { e ->
                    CoroutineScope(Dispatchers.IO).launch {
                        mutableFlow.emit("Error")
                    }

                }
        }

        CoroutineScope(Dispatchers.IO).launch {
            val recognizer = TextRecognition.getClient(devanagariTextRecognizerOptions)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank())
                        CoroutineScope(Dispatchers.IO).launch {
                            mutableFlow.emit(visionText.text)
                        }
                }
                .addOnFailureListener { e ->
                    CoroutineScope(Dispatchers.IO).launch {
                        mutableFlow.emit("Error")
                    }

                }
        }

        CoroutineScope(Dispatchers.IO).launch {
            val recognizer = TextRecognition.getClient(japaneseTextRecognizerOptions)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank())
                        CoroutineScope(Dispatchers.IO).launch {
                            mutableFlow.emit(visionText.text)
                        }
                }
                .addOnFailureListener { e ->
                    CoroutineScope(Dispatchers.IO).launch {
                        mutableFlow.emit("Error")
                    }

                }
        }

        CoroutineScope(Dispatchers.IO).launch {
            val recognizer = TextRecognition.getClient(koreanTextRecognizerOptions)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (visionText.text.isNotBlank())
                        CoroutineScope(Dispatchers.IO).launch {
                            mutableFlow.emit(visionText.text)
                        }
                }
                .addOnFailureListener { e ->
                    CoroutineScope(Dispatchers.IO).launch {
                        mutableFlow.emit("Error")
                    }

                }
        }

        return mutableFlow

    }

    suspend fun languageIdentification(text: String) {
        val languageIdentifier = LanguageIdentification.getClient()
        languageIdentifier.identifyLanguage(text)
            .addOnSuccessListener { languageCode ->
                if (languageCode != "und") {
                    CoroutineScope(Dispatchers.IO).launch {
                        saveFromLanguage(languageCode)
                    }
                }
            }
            .addOnFailureListener {

            }
    }


}

fun View.hideKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(windowToken, 0)
}